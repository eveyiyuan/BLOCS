import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;

public class DisplayFrame extends JFrame{
	
	public DisplayFrame(){
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		add(new DisplayPanel(), BorderLayout.CENTER);
		pack();
		setVisible(true);
	}
}
