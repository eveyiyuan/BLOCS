import java.util.*;

public class BLOC {
    DisplayPanel BLOCPanel;
    int player;
    int money = 1500;
    int propagandaMarker = 0;
    int influence = 0;
    int goodsExported = 0;
    int[] goods = new int[4];
    //index 0 = agriculture
    //index 1 = textiles
    //index 2 = tanks
    //index 3 = atomic bombs
    int[] buildings = new int[8];
    //index 0 = farm
    //index 1 = textile factory
    //index 2 = automobile factory
    //index 3 = nuclear silo
    int[] propagandaArray = { 0, 1, 2, 3, 5, 8, 13, 21 };
    Board playerBoard = new Board();
    ArrayList<Integer> buildingPics = new ArrayList<Integer>();
    
    public BLOC(int num, DisplayPanel d){
        player = num;
        BLOCPanel = d;
    }
    
    public int industry(int action){
        int sum = 0;
        for(int i = 0; i < 4; i++){
            sum += buildings[i];
        }
        if(sum < 12){
            buildings[action]++;
            if(action == 0 && money >= 500){
                money -= 500;
                buildingPics.add(action);
            }
            else if(action == 1 && money >= 1000){
                money -= 1000;
                buildingPics.add(action);
            }
            else if(action == 2 && money >= 2000){
                money -= 2000;
                buildingPics.add(action);
            }
            else if(action == 3 && money >= 4000){
                money -= 4000;
                buildingPics.add(action);
            }
            else if(action == 4 && money >= 5000){
            	money -= 5000;
            	buildingPics.add(action);
            }
            else if(action == 5 && money >= 5000){
            	money -= 5000;
            	buildingPics.add(action);
            }
            else if(action == 6 && money >= 5000){
            	money -= 5000;
            	buildingPics.add(action);
            }
            else if(action == 7 && money >= 5000){
            	money -= 5000;
            	buildingPics.add(action);
            }
            else{
                buildings[action]--;
                return 9;
            }
        }
        else{
            return 9;
        }
        return 0;
    }
    
    public void manufacture(){
        for(int i = 0; i < 4; i++){
            goods[i] += buildings[i];
        }
    }
    
    public void export(int agriculture, int textiles, int tanks, int bombs){
        goods[0] -= agriculture;
        money += agriculture * 250;
        goods[1] -= textiles;
        money += textiles * 400;
        goods[2] -= tanks;
        money += tanks * 700;
        goods[3] -= bombs;
        money += bombs * 1200;
        goodsExported += agriculture + textiles + tanks + bombs;
    }
    
    public int patronage(int agriculture, int textiles, int tanks, int bombs){
        int[] arr = {agriculture, textiles, tanks, bombs};
        int sum = 0, zeros = 0;
        boolean valid = true;
        for(int i = 0 ; i < 4; i++){
            if(arr[i] == 0){
                zeros++;
            }
            if(arr[i] != 0 && arr[i] != 1){
                valid = false;
            }
            sum += arr[i];
        }
        if(valid || (zeros == 3 && sum <= 4)){
            goods[0] -= agriculture;
            goods[1] -= textiles;
            goods[2] -= tanks;
            goods[3] -= bombs;
            influence += agriculture;
            influence += textiles * 2;
            influence += tanks * 3;
            influence += bombs * 4;
        }
        else{
            return 6;
        }
        return 0;
    }
    
    public int sabotage(int action, BLOC enemy, int industryDestroyed){
        if(action == 0 && money >= 1200){
            //sabotage influence
            money -= 1200;
            enemy.influence -= 3;
            if(enemy.influence < 0)
                enemy.influence = 0;
        }
        else if(action == 1 && money >= 5000){
            //sabotage propaganda markers
            money -= 5000;
            for(int i = 0; i < 4; i++){
                if(BLOCPanel.players.get(i).player != player){
                    BLOCPanel.players.get(i).propagandaMarker--;
                    if(BLOCPanel.players.get(i).propagandaMarker < 0)
                    	BLOCPanel.players.get(i).propagandaMarker = 0;
                }
            }
        }
        else if(action == 2 && money >= 1000){
            //sabotage boards
            money -= 1000;
            int x = (int) (Math.random() * 6);
            int y = (int) (Math.random() * 6);
            while(x == y)
                y = (int) (Math.random() * 6);
            int value = enemy.playerBoard.circles[x];
            enemy.playerBoard.circles[x] = enemy.playerBoard.circles[y];
            enemy.playerBoard.circles[y] = value;
        }
        else if(action == 3){
            //sabotage industry
            if(industryDestroyed == 0 && money >= 1000 && enemy.buildings[0] > 1){
                money -= 1000;
                enemy.buildings[0]--;
            }
            else if(industryDestroyed == 1 && money >= 2000 && enemy.buildings[1] > 1){
                money -= 2000;
                enemy.buildings[1]--;
            }
            else if(industryDestroyed == 2 && money >= 4000 && enemy.buildings[2] > 1){
                money -= 4000;
                enemy.buildings[2]--;
            }
            else if(industryDestroyed == 3 && money >= 8000 && enemy.buildings[3] > 1){
                money -= 8000;
                enemy.buildings[3]--;
            }
            else{
                return 7;
            }
        }
        else
            return 7;
        
        return 0;
    }
    
    public int propaganda(){
        if(money >= 100){
            propagandaMarker++;
            if(propagandaMarker == 8){
                propagandaMarker--;
            }
            influence += propagandaArray[propagandaMarker];
            money -= 100;
            return 0;
        }
        else{
            return 8;
        }
    }
    
    public String toString(){
        if(player == 1){
            return "Northern BLOC";
        }
        else if(player == 2){
            return "Eastern BLOC";
        }
        else if(player == 3){
            return "Western BLOC";
        }
        else if(player == 4){
            return "Southern BLOC";
        }
        return "BLOC";
    }
    
}
