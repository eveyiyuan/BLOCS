import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;


public class DisplayPanel extends JPanel implements MouseListener, KeyListener{
    
    public static ArrayList<BLOC> players;
    public int turnCounter = 1;
    public int roundCounter = 1;
    private DisplayFrame game;
    private boolean startTurn;
    private BLOC runningPlayer;
    private int inputDisplay;
    private int width, height;
    private Image mapImage, boardImage;
    private Image marble1, marble2, marble3, marble4;
    private Image marble5, marble6, marble7, marble8;
    private Image marble9, marble10, marble11, marble12;
    private Image PropN, PropS, PropE, PropW;
    private Image Farm, TextileFactory, AutoFactory, NuclearSilo;
    private Image IndustryHouse, PointsHouse, PropHouse, Shipyard;
    private Image Agriculture, Textiles, Tank, NuclearWeapons;
    private Image EndTurn, Confirm;
    private Image SabBoar, SabInd, SabInflu, SabProp;
    private int text;
    private boolean bool = true;
    private boolean iHouse = true, pHouse = true, prHouse = true, ship = true;
    //index 0 = industry
    //index 1 = manufacture
    //index 2 = export
    //index 3 = patronage
    //index 4 = propaganda3
    //index 5 = sabotage
    
    public DisplayPanel(){
    	addMouseListener(this);
    	setPreferredSize(new Dimension(1280,720));
        width = 1280;
        height = 720;
        getImages();
        players = new ArrayList<BLOC>();
        for(int i = 0; i < 4; i++)
            players.add(new BLOC(i + 1, this));
        text = 1;
        runningPlayer = players.get(0);
        repaint();
    }
    
    private void getImages(){
        // TODO Auto-generated method stub
        try{
            boardImage = ImageIO.read(new File("Board.gif"));
            mapImage = ImageIO.read(new File("Map.gif"));
            PropN = ImageIO.read(new File("PropN.gif"));
            PropE = ImageIO.read(new File("PropE.gif"));
            PropW = ImageIO.read(new File("PropW.gif"));
            PropS = ImageIO.read(new File("PropS.gif"));
            Farm = ImageIO.read(new File("Farm.gif"));
            TextileFactory = ImageIO.read(new File("Textile Factory.gif"));
            AutoFactory = ImageIO.read(new File("Auto Factory.gif"));
            NuclearSilo = ImageIO.read(new File("Nuclear Silo.gif"));
            EndTurn = ImageIO.read(new File("End Turn.gif"));
            Confirm = ImageIO.read(new File("Confirm.gif"));
            SabBoar = ImageIO.read(new File("sabBoar.gif"));
            SabInd = ImageIO.read(new File("sabInd.gif"));
            SabInflu = ImageIO.read(new File("sabInflu.gif"));
            SabProp = ImageIO.read(new File("sabProp.gif"));
            IndustryHouse = ImageIO.read(new File("Industry House.gif"));
            PointsHouse = ImageIO.read(new File("Points House.gif"));
            PropHouse = ImageIO.read(new File("Prop. House.gif"));
            Shipyard = ImageIO.read(new File("Shipyard.gif"));
            Agriculture = ImageIO.read(new File("Agriculture.gif"));
            Textiles = ImageIO.read(new File("Textiles.gif"));
            Tank = ImageIO.read(new File("Tank.gif"));
            NuclearWeapons = ImageIO.read(new File("Nuclear Weapons.gif"));
        } catch(IOException e){
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void paintComponent(Graphics g){
    	super.paintComponent(g);
    	if(bool){
    		setBackground(new Color(168, 20, 20));
    		bool = false;
    	}
        g.setColor(new Color(255, 255, 255, 150));
        g.fillRoundRect(25, 25, 157, 50, 10, 10);
        g.fillRoundRect(207, 25, 200, 50, 10, 10);
        g.drawImage(boardImage, 25, 100, 382, 595, null);
        g.drawImage(mapImage, 432, 25, 823, 437, null);
        g.fillRoundRect(432, 517, 438, 178, 10, 10);
        g.fillRoundRect(895, 517, 360, 178, 10, 10);
        g.fillRoundRect(432, 462, 823, 30, 10, 10);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 25, 157, 50, 10, 10);
        g.drawRoundRect(207, 25, 200, 50, 10, 10);
        g.drawRoundRect(432, 25, 823, 437, 0, 0);
        g.drawRoundRect(432, 462, 823, 30, 10, 10);
        g.drawRoundRect(432, 517, 438, 178, 10, 10);
        g.drawRoundRect(895, 517, 360, 178, 10, 10);
        g.setFont(new Font("Colonna MT", 0, 25));
        g.drawString("Round " + roundCounter + "/40", 35, 58);
        g.drawString(players.get(turnCounter - 1).toString(), 225, 58);
        try{
        //well 0
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[0] + ".gif")), 125, 105, 180, 180, null);
        //well 1
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[1] + ".gif")), 196, 225, 180, 180, null);
        //well 2
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[2] + ".gif")), 194, 378, 180, 180, null);
        //well 3
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[3] + ".gif")), 120, 500, 180, 180, null);
        //well 4
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[4] + ".gif")), 50, 378, 180, 180, null);
        //well 5
        g.drawImage(ImageIO.read(new File(players.get(turnCounter - 1).playerBoard.circles[5] + ".gif")), 50, 227, 180, 180, null);
        } catch(IOException e){
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        g.drawImage(PropN, 1010, 405 - 43 * players.get(0).propagandaMarker, 33, 32, null);
        g.drawImage(PropE, 1010, 382 - 43 * players.get(1).propagandaMarker, 33, 32, null);
        g.drawImage(PropW, 1224, 405 - 43 * players.get(2).propagandaMarker, 33, 32, null);
        g.drawImage(PropS, 1224, 382 - 43 * players.get(3).propagandaMarker, 33, 32, null);
        g.setFont(new Font("Segoe UI Bold", 0, 14));
        if(text != -1){
	        g.drawString("Influence Points:", 445, 540);
	        g.drawString(players.get(turnCounter - 1).influence + "", 558, 540);
	        g.drawString("Money: $", 690, 540);
	        g.drawString(players.get(turnCounter - 1).money + "", 752, 540);
	        g.drawString("Industries", 445, 570);
	        g.drawString("Manufactures", 730, 570);
	        g.setFont(new Font("Segoe UI", 0, 14));
	        g.drawString("Farms (" + players.get(turnCounter - 1).buildings[0] + ")", 445, 590);
	        g.drawString("Textile Factories (" + players.get(turnCounter - 1).buildings[1] + ")", 445, 610);
	        g.drawString("Auto Factories (" + players.get(turnCounter - 1).buildings[2] + ")", 445, 630);
	        g.drawString("Nuclear Silos (" + players.get(turnCounter - 1).buildings[3] + ")", 445, 650);
	        g.drawString("Prop. House (" + players.get(turnCounter - 1).buildings[4] + ")", 590, 590);
	        g.drawString("Industry House (" + players.get(turnCounter - 1).buildings[5] + ")", 590, 610);
	        g.drawString("Points House (" + players.get(turnCounter - 1).buildings[6] + ")", 590, 630);
	        g.drawString("Shipyard (" + players.get(turnCounter - 1).buildings[7] + ")", 590, 650);
	        g.drawString("Agriculture (" + players.get(turnCounter - 1).goods[0] + ")", 730, 590);
	        g.drawString("Textiles (" + players.get(turnCounter - 1).goods[1] + ")", 730, 610);
	        g.drawString("Tanks (" + players.get(turnCounter - 1).goods[2] + ")", 730, 630);
	        g.drawString("Nuclear Weapons (" + players.get(turnCounter - 1).goods[3] + ")", 730, 650);
        }
        g.setFont(new Font("Segoe UI Bold", 0, 16));
        g.drawString("Influence", 630, 120);
        g.drawString("Points", 640, 140);
        g.drawString("Influence", 910, 120);
        g.drawString("Points", 920, 140);
        g.drawString("Influence", 630, 350);
        g.drawString("Points", 640, 370);
        g.drawString("Influence", 910, 350);
        g.drawString("Points", 920, 370);
        g.setFont(new Font("Segoe UI Bold", 0, 40));
        g.drawString(players.get(0).influence + "", 640, 190);
        g.drawString(players.get(1).influence + "", 920, 190);
        g.drawString(players.get(2).influence + "", 640, 420);
        g.drawString(players.get(3).influence + "", 920, 420);
	    for(int i = 0; i < players.get(0).buildingPics.size(); i++){
        	int x = 454 + 49 * (i % 3);
        	int y = (i / 3 + 1) * 45;
        	if(players.get(0).buildingPics.get(i) == 0)
        		g.drawImage(Farm, x, y, 42, 38, null);
        	else if(players.get(0).buildingPics.get(i) == 1)
        		g.drawImage(TextileFactory, x, y, 42, 38, null);
        	else if(players.get(0).buildingPics.get(i) == 2)
        		g.drawImage(AutoFactory, x, y, 42, 38, null);
        	else if(players.get(0).buildingPics.get(i) == 3)
        		g.drawImage(NuclearSilo, x, y, 42, 38, null);
        	else if(players.get(0).buildingPics.get(i) == 4 && iHouse){
        		g.drawImage(IndustryHouse, x, y, 42, 38, null);
        		iHouse = false;
        	}
        	else if(players.get(0).buildingPics.get(i) == 5 && pHouse){
        		g.drawImage(PointsHouse, x, y, 42, 38, null);
        		pHouse = false;
        	}
        	else if(players.get(0).buildingPics.get(i) == 6 && prHouse){
        		g.drawImage(PropHouse, x, y, 42, 38, null);
        		prHouse = false;
        	}
        	else if(players.get(0).buildingPics.get(i) == 7 && ship){
        		g.drawImage(Shipyard, x, y, 42, 38, null);
        		ship = false;
        	}
        }
        for(int i = 0; i < players.get(1).buildingPics.size(); i++){
        	int x = 736 + 49 * (i % 3);
        	int y = (i / 3 + 1) * 45 + 1;
        	if(players.get(1).buildingPics.get(i) == 0)
        		g.drawImage(Farm, x, y, 42, 38, null);
        	else if(players.get(1).buildingPics.get(i) == 1)
        		g.drawImage(TextileFactory, x, y, 42, 38, null);
        	else if(players.get(1).buildingPics.get(i) == 2)
        		g.drawImage(AutoFactory, x, y, 42, 38, null);
        	else if(players.get(1).buildingPics.get(i) == 3)
        		g.drawImage(NuclearSilo, x, y, 42, 38, null);
        	else if(players.get(1).buildingPics.get(i) == 4 && iHouse){
        		g.drawImage(IndustryHouse, x, y, 42, 38, null);
        		iHouse = false;
        	}
        	else if(players.get(1).buildingPics.get(i) == 5 && pHouse){
        		g.drawImage(PointsHouse, x, y, 42, 38, null);
        		pHouse = false;
        	}
        	else if(players.get(1).buildingPics.get(i) == 6 && prHouse){
        		g.drawImage(PropHouse, x, y, 42, 38, null);
        		prHouse = false;
        	}
        	else if(players.get(1).buildingPics.get(i) == 7 && ship){
        		g.drawImage(Shipyard, x, y, 42, 38, null);
        		ship = false;
        	}
        }
        for(int i = 0; i < players.get(2).buildingPics.size(); i++){
        	int x = 456 + 49 * (i % 3);
        	int y = 274 + (i / 3) * 45;
        	if(players.get(2).buildingPics.get(i) == 0)
        		g.drawImage(Farm, x, y, 42, 38, null);
        	else if(players.get(2).buildingPics.get(i) == 1)
        		g.drawImage(TextileFactory, x, y, 42, 38, null);
        	else if(players.get(2).buildingPics.get(i) == 2)
        		g.drawImage(AutoFactory, x, y, 42, 38, null);
        	else if(players.get(2).buildingPics.get(i) == 3)
        		g.drawImage(NuclearSilo, x, y, 42, 38, null);
        	else if(players.get(2).buildingPics.get(i) == 4 && iHouse){
        		g.drawImage(IndustryHouse, x, y, 42, 38, null);
        		iHouse = false;
        	}
        	else if(players.get(2).buildingPics.get(i) == 5 && pHouse){
        		g.drawImage(PointsHouse, x, y, 42, 38, null);
        		pHouse = false;
        	}
        	else if(players.get(2).buildingPics.get(i) == 6 && prHouse){
        		g.drawImage(PropHouse, x, y, 42, 38, null);
        		prHouse = false;
        	}
        	else if(players.get(2).buildingPics.get(i) == 7 && ship){
        		g.drawImage(Shipyard, x, y, 42, 38, null);
        		ship = false;
        	}
        }
        for(int i = 0; i < players.get(3).buildingPics.size(); i++){
        	int x = 738 + 49 * (i % 3);
        	int y = 275 + (i / 3) * 45;
        	if(players.get(3).buildingPics.get(i) == 0)
        		g.drawImage(Farm, x, y, 42, 38, null);
        	else if(players.get(3).buildingPics.get(i) == 1)
        		g.drawImage(TextileFactory, x, y, 42, 38, null);
        	else if(players.get(3).buildingPics.get(i) == 2)
        		g.drawImage(AutoFactory, x, y, 42, 38, null);
        	else if(players.get(3).buildingPics.get(i) == 3)
        		g.drawImage(NuclearSilo, x, y, 42, 38, null);
        	else if(players.get(3).buildingPics.get(i) == 4 && iHouse){
        		g.drawImage(IndustryHouse, x, y, 42, 38, null);
        		iHouse = false;
        	}
        	else if(players.get(3).buildingPics.get(i) == 5 && pHouse){
        		g.drawImage(PointsHouse, x, y, 42, 38, null);
        		pHouse = false;
        	}
        	else if(players.get(3).buildingPics.get(i) == 6 && prHouse){
        		g.drawImage(PropHouse, x, y, 42, 38, null);
        		prHouse = false;
        	}
        	else if(players.get(3).buildingPics.get(i) == 7 && ship){
        		g.drawImage(Shipyard, x, y, 42, 38, null);
        		ship = false;
        	}
        }
        g.setFont(new Font("Segoe UI", 0, 14));
        if(text == -2){
        	turnCounter++;
        	if(turnCounter == 5){
        		turnCounter = 1;
        		roundCounter++;
        	}
        	if(roundCounter == 40){
        		endGame();
        	}
        	runningPlayer = players.get(turnCounter - 1);
        	text = 1;
        	repaint();
        }
        else if(text == -1){
        	g.drawImage(boardImage, 25, 100, 382, 595, null);
        	g.drawImage(Confirm, 900, 570, 350, 81, null);
        	if(turnCounter != 4)
        		changeCommand(players.get(turnCounter).toString() + ", press CONFIRM to begin your turn.", g);
        	else
        		changeCommand(players.get(0).toString() + ", press CONFIRM to begin your turn.", g);
            if(turnCounter == 1){
                setBackground(new Color(39, 45, 122));
            }
            if(turnCounter == 2){
                setBackground(new Color(4, 87, 35));
            }
            if(turnCounter == 3){    
                setBackground(new Color(255, 231, 125));
            }
            if(turnCounter == 4){
                setBackground(new Color(168, 20, 20));
            }
        }
        else if(text == 0){
        	g.drawImage(EndTurn, 900, 570, 350, 81, null);
        }
        else if(text == 1){
        	changeCommand("Please choose a well to empty.", g);
        }
        else if(text == 2){
        	changeCommand("Please choose an industry to develop.", g);
        	g.drawImage(Farm, 912, 530, 63, 57, null);
            g.drawString("Farm $500", 912, 602);
            g.drawImage(TextileFactory, 912, 613, 63, 57, null);
            g.drawString("Textile $1000", 900, 685);
            g.drawImage(AutoFactory, 1000, 530, 63, 57, null);
            g.drawString("Auto $2000", 1000, 602);
            g.drawImage(NuclearSilo, 1000, 613, 63, 57, null);
            g.drawString("Nuclear $4000", 990, 685);
            g.drawImage(IndustryHouse, 1088, 530, 63, 57, null);
            g.drawString("Industry B.", 1088, 602);
            g.drawImage(PointsHouse, 1088, 613, 63, 57, null);
            g.drawString("Points B.", 1088, 685);
            g.drawImage(PropHouse, 1176, 530, 63, 57, null);
            g.drawString("Prop. B.", 1176, 602);
            g.drawImage(Shipyard, 1176, 613, 63, 57, null);
            g.drawString("Export B.", 1176, 685);
        }
        else if(text == 3){
        	changeCommand("Please click again to choose goods for export.", g);
        	
        }
        else if(text == 4){
        	changeCommand("Please click again to choose which goods to provide for patronage.", g);
        	//display goods for patronage
        }
        else if(text == 5){
        	changeCommand("Please choose a method of sabotage.", g);
        	g.drawImage(SabBoar, 899, 550, 175, 40, null);
        	//g.drawImage(SabInd, 899, 620, 175, 40, null);
        	g.drawImage(SabInflu, 1077, 550, 175, 40, null);
        	g.drawImage(SabProp, 988, 620, 175, 40, null);
        }
        else if(text == 6){
        	changeCommand("Your choice is invalid. Please choose which goods to provide for patronage.", g);
        	//display possible choices (same as text == 4)
        }
        else if(text == 7){
        	changeCommand("Your choice is invalid. Please choose a method of sabotage.", g);
        }
        else if(text == 8){
        	changeCommand("You do not have the money to perform this action.", g);
        	text = 0;
        	repaint();
        }
        else if(text == 9){
        	changeCommand("You are unable to build this building.", g);
        	text = 0;
        	repaint();
        }
    }
    
    public void changeCommand(String s, Graphics g){
    	g.setFont(new Font("Segoe UI Bold", 0, 14));
        g.drawString(s, 450, 482);
    }
    
    @Override
    public void mousePressed(MouseEvent e){
        // TODO Auto-generated method stub
        int cX = (int) e.getPoint().getX();
        int cY = (int) e.getPoint().getY();
        
        //CHOOSE WELL ON MANCALA BOARD
        if(text == 1){
        	int action;
        	if((cX - 214) * (cX - 214) + (cY - 202) * (cY - 202) <= 2025 && runningPlayer.playerBoard.circles[0] != 0){
                inputDisplay = 0;
                action = runningPlayer.playerBoard.clicked(0);
        	}
        	else if((cX - 288) * (cX - 288) + (cY - 323) * (cY - 323) <= 2025 && runningPlayer.playerBoard.circles[1] != 0){
                inputDisplay = 1;
                action = runningPlayer.playerBoard.clicked(1);
        	}
        	else if((cX - 287) * (cX - 287) + (cY - 473) * (cY - 473) <= 2025 && runningPlayer.playerBoard.circles[2] != 0){
                inputDisplay = 2;
                action = runningPlayer.playerBoard.clicked(2);
        	}
        	else if((cX - 211) * (cX - 211) + (cY - 596) * (cY - 596) <= 2025 && runningPlayer.playerBoard.circles[3] != 0){
                inputDisplay = 3;
                action = runningPlayer.playerBoard.clicked(3);
        	}
        	else if((cX - 144) * (cX - 144) + (cY - 474) * (cY - 474) <= 2025 && runningPlayer.playerBoard.circles[4] != 0){
                inputDisplay = 4;
                action = runningPlayer.playerBoard.clicked(4);
        	}
        	else if((cX - 142) * (cX - 142) + (cY - 327) * (cY - 327) <= 2025 && runningPlayer.playerBoard.circles[5] != 0){
                inputDisplay = 5;
                action = runningPlayer.playerBoard.clicked(5);
        	}
            else{
            	return;
            }
            if(action == 0){
            	text = 2;
            }
            else if(action == 1){
            	text = 0;
            	runningPlayer.manufacture();
            }
            else if(action == 2){
            	text = 3;
            }
            else if(action == 3){
            	text = 4;
            }
            else if(action == 4){
            	text = 0;
            	runningPlayer.propaganda();
            }
            else if(action == 5){
            	text = 5;
            }
            repaint();
            return;
        }
        //CHOOSE WHAT DO DO
        if(text == 2){
        	if(cX >= 912 && cX <= 975 && cY >= 530 && cY <= 587)
        		text = runningPlayer.industry(0);
        	if(cX >= 912 && cX <= 975 && cY >= 613 && cY <= 670)
        		text = runningPlayer.industry(1);
        	if(cX >= 1000 && cX <= 1063 && cY >= 530 && cY <= 587)
        		text = runningPlayer.industry(2);
        	if(cX >= 1000 && cX <= 1063 && cY >= 613 && cY <= 670)
        		text = runningPlayer.industry(3);
        }
        else if(text == 3){
        	JTextField agriField = new JTextField("0",5);
        	JTextField textileField = new JTextField("0",5);
        	JTextField tankField = new JTextField("0",5);
        	JTextField bombField = new JTextField("0",5);
        	
        	JPanel input = new JPanel();
        	input.add(new JLabel("Agriculture:"));
        	input.add(agriField);
        	input.add(new JLabel("Textiles:"));
        	input.add(textileField);
        	input.add(new JLabel("Tanks:"));
        	input.add(tankField);
        	input.add(new JLabel("Nuclear Weapons:"));
        	input.add(bombField);
        	int result = JOptionPane.showConfirmDialog(null, input, "What do you want to export?", JOptionPane.OK_OPTION);
        	if(result == JOptionPane.OK_OPTION){
        		int a = Integer.parseInt(agriField.getText());
        		int tx = Integer.parseInt(textileField.getText());
        		int ta = Integer.parseInt(tankField.getText());
        		int b = Integer.parseInt(bombField.getText());
        		if(a > runningPlayer.goods[0])
        			a = runningPlayer.goods[0];
        		if(tx > runningPlayer.goods[1])
        			tx = runningPlayer.goods[1];
        		if(ta > runningPlayer.goods[2])
        			ta = runningPlayer.goods[2];
        		if(b > runningPlayer.goods[3])
        			b = runningPlayer.goods[3];
        		runningPlayer.export(a, tx, ta, b);
        	}
        	text = 0;
        }
        else if(text == 4){
        	JTextField agriField = new JTextField("0",5);
        	JTextField textileField = new JTextField("0",5);
        	JTextField tankField = new JTextField("0",5);
        	JTextField bombField = new JTextField("0",5);
        	
        	JPanel input = new JPanel();
        	input.add(new JLabel("Agriculture:"));
        	input.add(agriField);
        	input.add(new JLabel("Textiles:"));
        	input.add(textileField);
        	input.add(new JLabel("Tanks:"));
        	input.add(tankField);
        	input.add(new JLabel("Nuclear Weapons:"));
        	input.add(bombField);
        	int result = JOptionPane.showConfirmDialog(null, input, "What do you want to include in your patronage package?", JOptionPane.OK_OPTION);
        	if(result == JOptionPane.OK_OPTION){
        		int a = Integer.parseInt(agriField.getText());
        		int tx = Integer.parseInt(textileField.getText());
        		int ta = Integer.parseInt(tankField.getText());
        		int b = Integer.parseInt(bombField.getText());
        		if(a > runningPlayer.goods[0])
        			a = runningPlayer.goods[0];
        		if(tx > runningPlayer.goods[1])
        			tx = runningPlayer.goods[1];
        		if(ta > runningPlayer.goods[2])
        			ta = runningPlayer.goods[2];
        		if(b > runningPlayer.goods[3])
        			b = runningPlayer.goods[3];
        		runningPlayer.patronage(a, tx, ta, b);
        	}
        	text = 0;
        }
        else if(text == 5){
        	String[] nBLOC = {"Eastern BLOC", "Western BLOC","Southern BLOC"};
        	String[] eBLOC = {"Northern BLOC", "Western BLOC","Southern BLOC"};
        	String[] wBLOC = {"Northern BLOC", "Eastern BLOC","Southern BLOC"};
        	String[] sBLOC = {"Northern BLOC", "Eastern BLOC", "Western BLOC"};
        	String[] use = nBLOC;
    		if (runningPlayer.toString().equals("Northern BLOC"))
    			use = nBLOC;
    		if (runningPlayer.toString().equals("Eastern BLOC"))
    			use = eBLOC;
    		if (runningPlayer.toString().equals("Western BLOC"))
    			use = wBLOC;
    		if (runningPlayer.toString().equals("Southern BLOC"))
    			use = sBLOC;
    		
        	if(cX >= 899 && cX <= 1074 && cY >= 550 && cY <= 590){	
        		String userInput = (String)JOptionPane.showInputDialog(
        				null,
        				"Select a player",
        				"Sabotage a player's board",
        				JOptionPane.INFORMATION_MESSAGE,
        				null,
        				use,
        				use[0]);
        		
        		for (int i = 0; i<4; i++){
        			if (players.get(i).toString().equals(userInput)){
        				runningPlayer.sabotage(2, players.get(i), 0);
        				break;
        			}
        		}
        		text = 0;
        	}
//        	else if(cX >= 899 && cX <= 1074 && cY >= 620 && cY <= 660){
//        		BLOC p = players.get(1);
//        		String userInput = (String)JOptionPane.showInputDialog(
//        				null,
//        				"Select a player",
//        				"Sabotage a player's industry",
//        				JOptionPane.INFORMATION_MESSAGE,
//        				null,
//        				use,
//        				use[0]);
//        		
//        		for (int i = 0; i<4; i++){
//        			if (players.get(i).toString().equals(userInput)){
////        				runningPlayer.sabotage(3, players.get(i), 0);
//        				p = players.get(i);
//        			}
//        		}
//        		int sum = 0;
//        		for (int i = 0; i < 4; i++){
//        			sum += p.buildings[i];
//        		}
//        		if(sum == 0){
//        			text = 0;
//        			repaint();
//        			return;
//        		}
//        		
//        		String[] indus = null;
//        		int i = 0;
//        		if(p.buildings[0] !=0){
//        			indus[i] = "Farm";
//        			i++;
//        		}
//        		if(p.buildings[1] !=0){
//        			indus[i] = "Textile Factory";
//        			i++;
//        		}
//        		if(p.buildings[2] !=0){
//        			indus[i] = "Auto Factory";
//        			i++;
//        		}
//        		if(p.buildings[3] !=0){
//        			indus[i] = "Nuclear Silo";
//        		}
//        		
//        		String buildingInput = (String)JOptionPane.showInputDialog(
//        				null,
//        				"Select an industry",
//        				"Sabotage a player's industry",
//        				JOptionPane.INFORMATION_MESSAGE,
//        				null,
//        				indus,
//        				indus[0]);
//        		
//        		if(buildingInput.equals("Farm")){
//        			runningPlayer.sabotage(3, p, 0);
//        		}
//        		else if(buildingInput.equals("Textile Factory")){
//        			runningPlayer.sabotage(3, p, 1);
//        		}
//        		else if(buildingInput.equals("Auto Factory")){
//        			runningPlayer.sabotage(3, p, 2);
//        		}
//        		else if(buildingInput.equals("Nuclear Silo")){
//        			runningPlayer.sabotage(3, p, 3);
//        		}
//        		
//        	}
        	else if(cX >= 1077 && cX <= 1252 && cY >= 550 && cY <= 590){
        		String userInput = (String)JOptionPane.showInputDialog(
        				null,
        				"Select a player",
        				"Sabotage a player's influence",
        				JOptionPane.INFORMATION_MESSAGE,
        				null,
        				use,
        				use[0]);
        		
        		for (int i = 0; i<4; i++){
        			if (players.get(i).toString().equals(userInput)){
        				runningPlayer.sabotage(0, players.get(i), 0);
        				break;
        			}
        		}
        		text = 0;
        	}
        	else if(cX >= 988 && cX <= 1163 && cY >= 620 && cY <= 660){
        		runningPlayer.sabotage(1, runningPlayer, 0);
        		text = 0;
        	}
        }
        
        else if(text == 0 && cX >= 900 && cX <= 1250 && cY >= 570 && cY <= 651){
        	text = -1;
        }
        else if(text == -1 && cX >= 900 && cX <= 1250 && cY >= 570 && cY <= 651){
        	text = -2;
        }
        repaint();
    }
    
    public void endGame(){
        // TODO Auto-generated method stub
    	for(int i = 0; i < 4; i++){
            int sum = 0;
            for(int j = 0; j < 4; j++)
                sum += players.get(i).buildings[j];
            
            players.get(i).influence += players.get(i).buildings[4] * 2 * players.get(i).propagandaMarker;
            players.get(i).influence += players.get(i).buildings[5] * 3 * sum;
            players.get(i).influence += players.get(i).buildings[6] * 25;
            players.get(i).influence += players.get(i).buildings[7] * players.get(i).goodsExported;
        }
        String winner = "Northern Bloc";
        int curmax = players.get(0).influence;
        
        for(int i = 1; i < 4; i++){
            if(players.get(i).influence > curmax){
                winner = players.get(i).toString();
                curmax = players.get(i).influence;
            }
        }
        //print winner wins!
    }

    public void bonusTurn(){
        // TODO Auto-generated method stub
        
    }
    
    @Override
    public void keyTyped(KeyEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void keyPressed(KeyEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void keyReleased(KeyEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void mouseClicked(MouseEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void mouseReleased(MouseEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void mouseEntered(MouseEvent e){
        // TODO Auto-generated method stub
        
    }

    @Override
    public void mouseExited(MouseEvent e){
        // TODO Auto-generated method stub
        
    }

}