import java.util.*;

public class Board {
	int[] circles;
    public Board(){
    	circles = new int[6];
    	//index 0 = industry
    	//index 1 = manufacture
    	//index 2 = export
    	//index 3 = patronage
    	//index 4 = propaganda
    	//index 5 = sabotage
    	for(int i = 0; i < 6; i++)
    		circles[i] = 2;
    }
    
    public int clicked(int n){
    	int x = circles[n];
    	int counter = n + 1;
    	circles[n] = 0;
    	while(x != 0){
    		if(counter == 6)
    			counter = 0;
    		circles[counter]++;
    		x--;
    		counter++;
    	}
    	//display(); displays the changed symbols
    	return counter - 1;
    }
}
